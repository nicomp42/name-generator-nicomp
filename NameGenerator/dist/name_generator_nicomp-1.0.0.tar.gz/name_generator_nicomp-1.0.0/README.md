Description: This project generates silly names from a list of adjectives and a list of nouns
        
        Example::
        
            >>> from name_generator_nicomp.NameGenerator import NameGenerator
            >>> nameGenerator = NameGenerator()
            >>> print(nameGenerator.generate_name())
        
        
        
